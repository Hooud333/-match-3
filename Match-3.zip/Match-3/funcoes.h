#define TAM_MATRIZ 9
#define TAM_QUADRADO 50
#define QTD_IMAGENS 6

// Fun��o para desenhar a matriz na tela

void DesenhaMatriz(int matriz[TAM_MATRIZ][TAM_MATRIZ], int offsetX, int offsetY, Texture2D imagens[QTD_IMAGENS])
{
    for (int row = 0; row < TAM_MATRIZ; row++) {
        for (int col = 0; col < TAM_MATRIZ; col++) {
            // Calcula a posi��o (x, y) da c�lula
            int x = offsetX + col * TAM_QUADRADO;
            int y = offsetY + row * TAM_QUADRADO;

            //coloca imagens nos quadrados da matriz.
            int value = matriz[row][col];

            if (value >= 0 && value < 7) {
                DrawTextureEx(imagens[value], (Vector2){x, y}, 0.0f, (float)TAM_QUADRADO / imagens[value].width, WHITE);
            } else {
                // Se o valor for inv�lido, desenha uma c�lula preta
                DrawRectangle(x, y, TAM_QUADRADO, TAM_QUADRADO, GREEN);
            }

        }
    }
}

// Fun��o para gerar uma matriz com n�meros aleat�rios de 0 a 6
void GeraAleatorios(int matriz[TAM_MATRIZ][TAM_MATRIZ]) {
    for (int row = 0; row < TAM_MATRIZ; row++) {
        for (int col = 0; col < TAM_MATRIZ; col++) {
            matriz[row][col] = rand() % 7; // Gera n�mero entre 0 e 6
        }
    }
}
