#include <stdio.h>
#include <stdlib.h>
#include "raylib.h"
#include "funcoes.h"
#include "raylib.h"

#define TAM_MATRIZ 9
#define TAM_QUADRADO 50
#define QTD_IMAGENS 6

int main(void)
{
    const int screenWidth = 1000;
    const int screenHeight = 800;

    Texture2D imagens[QTD_IMAGENS];

    imagens[0] = LoadTexture("Others/imagens/logo_c.png");
    imagens[1] = LoadTexture("Others/imagens/logo_java.png");
    imagens[2] = LoadTexture("Others/imagens/logo_js.png");
    imagens[3] = LoadTexture("Others/imagens/logo_python.png");
    imagens[4] = LoadTexture("Others/imagens/logo_ruby.png");
    imagens[5] = LoadTexture("Others/imagens/logo_rust.png");


    InitWindow(screenWidth, screenHeight, " MATCH - 3 | Algoritmo e Programacao ");

    SetTargetFPS(60);

    int matriz[TAM_MATRIZ][TAM_MATRIZ];

    GeraAleatorios(matriz);

    // Calcula o deslocamento inicial para centralizar a matriz
    int totalWidth = TAM_MATRIZ * TAM_QUADRADO;  // Largura total da matriz
    int totalHeight = TAM_MATRIZ * TAM_QUADRADO; // Altura total da matriz
    int offsetX = (screenWidth - totalWidth) / 2; // Deslocamento horizontal
    int offsetY = (screenHeight - totalHeight) / 2; // Deslocamento vertical



    while (!WindowShouldClose())
    {

        BeginDrawing();

        ClearBackground(BLACK);

        DesenhaMatriz(matriz, offsetX, offsetY, imagens);

        EndDrawing();

    }

 CloseWindow();
}

