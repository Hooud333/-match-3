#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "raylib.h"

#define TAM_MATRIZ 9
#define TAM_QUADRADO 50
#define QTD_IMAGENS 6

void GeraAleatorios(int matriz[TAM_MATRIZ][TAM_MATRIZ]);
void DesenhaMatriz(int matriz[TAM_MATRIZ][TAM_MATRIZ], int offsetX, int offsetY, Texture2D imagens[QTD_IMAGENS]);

int main(void)
{
    const int screenWidth = 1000;
    const int screenHeight = 800;

    InitWindow(screenWidth, screenHeight, "MATCH-3 | Algoritmo e Programacao");

    Texture2D imagens[QTD_IMAGENS];

   imagens[0] = LoadTexture("imagens/logo_c.png");
imagens[1] = LoadTexture("imagens/logo_java.png");
imagens[2] = LoadTexture("imagens/logo_js.png");
imagens[3] = LoadTexture("imagens/logo_python.png");
imagens[4] = LoadTexture("imagens/logo_ruby.png");
imagens[5] = LoadTexture("imagens/logo_rust.png");


    SetTargetFPS(60);

    int matriz[TAM_MATRIZ][TAM_MATRIZ];

    srand(time(NULL));
    GeraAleatorios(matriz);

    // Calcula o deslocamento inicial para centralizar a matriz
    int totalWidth = TAM_MATRIZ * TAM_QUADRADO;  // Largura total da matriz
    int totalHeight = TAM_MATRIZ * TAM_QUADRADO; // Altura total da matriz
    int offsetX = (screenWidth - totalWidth) / 2; // Deslocamento horizontal
    int offsetY = (screenHeight - totalHeight) / 2; // Deslocamento vertical

    while (!WindowShouldClose())
    {
        BeginDrawing();

        ClearBackground(BLACK);

        // Desenha a matriz
        DesenhaMatriz(matriz, offsetX, offsetY, imagens);

        EndDrawing();
    }

    // Libera as texturas carregadas
    for (int i = 0; i < QTD_IMAGENS; i++) {
        if (imagens[i].id == 0) {
            printf("Erro ao carregar imagem %d\n", i);
        }
        UnloadTexture(imagens[i]); // Liberar as texturas corretamente
    }

    CloseWindow();

    return 0;
}

// Fun��o para desenhar a matriz na tela
void DesenhaMatriz(int matriz[TAM_MATRIZ][TAM_MATRIZ], int offsetX, int offsetY, Texture2D imagens[QTD_IMAGENS])
{
    for (int row = 0; row < TAM_MATRIZ; row++) {
        for (int col = 0; col < TAM_MATRIZ; col++) {
            // Calcula a posi��o (x, y) da c�lula
            int x = offsetX + col * TAM_QUADRADO;
            int y = offsetY + row * TAM_QUADRADO;

            // Pega o valor da matriz
            int value = matriz[row][col];

            // Verifica se o valor � v�lido
            if (value >= 0 && value < QTD_IMAGENS) {
                float scale = (float)TAM_QUADRADO / imagens[value].width;
                DrawTextureEx(imagens[value], (Vector2){x, y}, 0.0f, scale, WHITE);
            } else {
                // Se o valor for inv�lido, desenha uma c�lula preta
                DrawRectangle(x, y, TAM_QUADRADO, TAM_QUADRADO, GREEN);
            }

            // Desenha o contorno da c�lula
            DrawRectangleLines(x, y, TAM_QUADRADO, TAM_QUADRADO, DARKGRAY);
        }
    }
}

// Fun��o para gerar uma matriz com n�meros aleat�rios de 0 a 5
void GeraAleatorios(int matriz[TAM_MATRIZ][TAM_MATRIZ]) {
    for (int row = 0; row < TAM_MATRIZ; row++) {
        for (int col = 0; col < TAM_MATRIZ; col++) {
            matriz[row][col] = rand() % QTD_IMAGENS; // Gera n�mero entre 0 e 5
        }
    }
}
